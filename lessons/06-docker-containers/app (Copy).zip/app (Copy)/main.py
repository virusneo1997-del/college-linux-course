from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List
import asyncpg
import os

app = FastAPI(title="College API", version="1.0.0")

# Модели данных
class Student(BaseModel):
    id: int = None
    first_name: str
    last_name: str
    email: str
    group_name: str = None

class Course(BaseModel):
    id: int = None
    title: str
    description: str = None

# Подключение к базе данных
async def get_db_connection():
    return await asyncpg.connect(
        host=os.getenv('DB_HOST', 'db'),
        database=os.getenv('DB_NAME', 'college'),
        user=os.getenv('DB_USER', 'college_user'),
        password=os.getenv('DB_PASSWORD', 'college_password')
    )

@app.get("/")
async def root():
    return {"message": "College Management System API", "version": "1.0.0"}

@app.get("/students", response_model=List[Student])
async def get_students():
    conn = await get_db_connection()
    try:
        students = await conn.fetch("SELECT * FROM students ORDER BY id")
        return [dict(student) for student in students]
    finally:
        await conn.close()

@app.post("/students", response_model=Student)
async def create_student(student: Student):
    conn = await get_db_connection()
    try:
        student_id = await conn.fetchval(
            "INSERT INTO students (first_name, last_name, email, group_name) VALUES ($1, $2, $3, $4) RETURNING id",
            student.first_name, student.last_name, student.email, student.group_name
        )
        student.id = student_id
        return student
    finally:
        await conn.close()

@app.get("/courses", response_model=List[Course])
async def get_courses():
    conn = await get_db_connection()
    try:
        courses = await conn.fetch("SELECT * FROM courses ORDER BY id")
        return [dict(course) for course in courses]
    finally:
        await conn.close()

if name == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
